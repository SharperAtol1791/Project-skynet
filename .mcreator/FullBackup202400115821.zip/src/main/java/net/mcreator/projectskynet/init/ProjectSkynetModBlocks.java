
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectskynet.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.projectskynet.block.SkystoneBlock;
import net.mcreator.projectskynet.block.SkylogBlock;
import net.mcreator.projectskynet.block.SkyleavesBlock;
import net.mcreator.projectskynet.block.SkygrassBlock;
import net.mcreator.projectskynet.block.SkydirtBlock;
import net.mcreator.projectskynet.ProjectSkynetMod;

public class ProjectSkynetModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, ProjectSkynetMod.MODID);
	public static final DeferredHolder<Block, Block> SKYDIRT = REGISTRY.register("skydirt", () -> new SkydirtBlock());
	public static final DeferredHolder<Block, Block> SKYGRASS = REGISTRY.register("skygrass", () -> new SkygrassBlock());
	public static final DeferredHolder<Block, Block> SKYLOG = REGISTRY.register("skylog", () -> new SkylogBlock());
	public static final DeferredHolder<Block, Block> SKYLEAVES = REGISTRY.register("skyleaves", () -> new SkyleavesBlock());
	public static final DeferredHolder<Block, Block> SKYSTONE = REGISTRY.register("skystone", () -> new SkystoneBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
