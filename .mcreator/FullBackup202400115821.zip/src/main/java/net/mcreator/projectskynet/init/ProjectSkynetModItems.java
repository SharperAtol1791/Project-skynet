
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectskynet.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.projectskynet.item.CopperSwordItem;
import net.mcreator.projectskynet.item.CopperShovelItem;
import net.mcreator.projectskynet.item.CopperPickaxeItem;
import net.mcreator.projectskynet.item.CopperHoeItem;
import net.mcreator.projectskynet.item.CopperAxeItem;
import net.mcreator.projectskynet.ProjectSkynetMod;

public class ProjectSkynetModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, ProjectSkynetMod.MODID);
	public static final DeferredHolder<Item, Item> COPPER_PICKAXE = REGISTRY.register("copper_pickaxe", () -> new CopperPickaxeItem());
	public static final DeferredHolder<Item, Item> COPPER_AXE = REGISTRY.register("copper_axe", () -> new CopperAxeItem());
	public static final DeferredHolder<Item, Item> COPPER_SWORD = REGISTRY.register("copper_sword", () -> new CopperSwordItem());
	public static final DeferredHolder<Item, Item> COPPER_SHOVEL = REGISTRY.register("copper_shovel", () -> new CopperShovelItem());
	public static final DeferredHolder<Item, Item> COPPER_HOE = REGISTRY.register("copper_hoe", () -> new CopperHoeItem());
	public static final DeferredHolder<Item, Item> SKYDIRT = block(ProjectSkynetModBlocks.SKYDIRT);
	public static final DeferredHolder<Item, Item> SKYGRASS = block(ProjectSkynetModBlocks.SKYGRASS);
	public static final DeferredHolder<Item, Item> SKYLOG = block(ProjectSkynetModBlocks.SKYLOG);
	public static final DeferredHolder<Item, Item> SKYLEAVES = block(ProjectSkynetModBlocks.SKYLEAVES);
	public static final DeferredHolder<Item, Item> SKYSTONE = block(ProjectSkynetModBlocks.SKYSTONE);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
