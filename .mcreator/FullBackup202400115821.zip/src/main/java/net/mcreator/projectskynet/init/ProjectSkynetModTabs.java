
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectskynet.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.projectskynet.ProjectSkynetMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ProjectSkynetModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ProjectSkynetMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ProjectSkynetModItems.COPPER_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ProjectSkynetModItems.COPPER_PICKAXE.get());
			tabData.accept(ProjectSkynetModItems.COPPER_AXE.get());
			tabData.accept(ProjectSkynetModItems.COPPER_SHOVEL.get());
			tabData.accept(ProjectSkynetModItems.COPPER_HOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ProjectSkynetModBlocks.SKYDIRT.get().asItem());
			tabData.accept(ProjectSkynetModBlocks.SKYGRASS.get().asItem());
			tabData.accept(ProjectSkynetModBlocks.SKYLOG.get().asItem());
			tabData.accept(ProjectSkynetModBlocks.SKYLEAVES.get().asItem());
			tabData.accept(ProjectSkynetModBlocks.SKYSTONE.get().asItem());
		}
	}
}
